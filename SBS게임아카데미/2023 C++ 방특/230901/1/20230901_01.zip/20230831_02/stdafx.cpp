#include "stdafx.h"

#ifndef COMPLIED_CONSOLE
#define COMPLIED_CONSOLE

#include "TConsole.h"
tvision::TConsole tvision::TConsole::theInstance;

#endif