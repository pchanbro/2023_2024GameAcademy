#pragma once
struct Unit
{
	int Hp;
	int Mp;
};
