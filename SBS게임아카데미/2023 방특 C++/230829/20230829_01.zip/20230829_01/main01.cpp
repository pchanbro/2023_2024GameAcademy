﻿#include <iostream>
using namespace std;

void main() 
{
	//1. 빙고 타임어택.
}