#pragma once
#include <iostream>
#include <conio.h>
#include <time.h>
#include <Windows.h>

using namespace std;
