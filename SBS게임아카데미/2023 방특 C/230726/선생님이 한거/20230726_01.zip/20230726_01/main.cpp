﻿#include <iostream>
#include <time.h>
#include <Windows.h>
#include <conio.h>

#define COMPLIED_CONSOLE
#include "TConsole.h"

tvision::TConsole tvision::TConsole::theInstance;

#define CustomConsole tvision ::TConsole::GetConsole()
using namespace std;

DWORD oriColor = GREEN;

void setPixelColor(DWORD color)
{
	CustomConsole.SetBkColor(color);
	cout << "ㅤ";
}
void ShowMyCharacter(int x, int y)
{
	CustomConsole.GotoXY(x, y);
	setPixelColor(oriColor);	setPixelColor(WHITE);		setPixelColor(oriColor);	setPixelColor(oriColor);	setPixelColor(oriColor);	setPixelColor(WHITE);		setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 1);
	setPixelColor(oriColor);	setPixelColor(RED);			setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(RED);			setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 2);
	setPixelColor(oriColor);	setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(LIGHTRED);	setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 3);
	setPixelColor(oriColor);	setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 4);
	setPixelColor(oriColor);	setPixelColor(LIGHTRED);	setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(LIGHTRED);	setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 5);
	setPixelColor(oriColor);	setPixelColor(LIGHTRED);	setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(LIGHTRED);	setPixelColor(oriColor);
	CustomConsole.GotoXY(x, y + 6);
	setPixelColor(oriColor);	setPixelColor(LIGHTRED);	setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(BLACK);		setPixelColor(LIGHTRED);	setPixelColor(oriColor);

	CustomConsole.SetBkColor(oriColor);
}

int main()
{
	CustomConsole.SetCursor(tvision::CursorMode::CURSOR_OFF);

	CustomConsole.setFontSize(6);
	CustomConsole.SetWindowSize(210, 105);
	CustomConsole.ClearScreen(GREEN);

	CustomConsole.SetTitle("안녕하세요22");
	CustomConsole.SetCursor(tvision::CURSOR_OFF);
	int x = 7;

	while (true)
	{
		if (_kbhit())
		{
			char input = _getch();
			switch (input)
			{
			case 'w':
				x++;
				CustomConsole.ClearArea(x, 3, x + 7, 3 + 7);
				ShowMyCharacter(x, 3);
				break;
			default:
				break;
			}
		}
	}

	return 0;
}