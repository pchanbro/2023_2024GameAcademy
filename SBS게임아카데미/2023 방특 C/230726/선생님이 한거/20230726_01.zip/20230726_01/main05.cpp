#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

void main()
{
	char str[256];

	scanf("%s", str);
	printf("%s", str);
}